package drivers;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;


public class WebDriverSetup {
	
	WebDriver driver;
	
	//Setting up the WebDriver and WebPage...
	
	public void setup(String browser) {
		
		System.out.println("Setup method called...");
		
		if (browser.equals("Chrome")) {
			driver = new ChromeDriver();
		} else if (browser.equals("Edge")) {
			driver = new EdgeDriver();
		}
		
		driver.manage().window().maximize();
		System.out.println(browser + " has been set up");
		
		
	}
	
	//Fetching the driver...
	
	public WebDriver getDriver() {
		System.out.println("getDriver method called...");
		return driver;
	}

}
