package main;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;

import becognizant.BeCognizantHolidayCalendar;
import becognizant.BeCognizantHolidaySchedules;
import becognizant.BeCognizantHome;
import drivers.WebDriverSetup;


public class MainTest {
  

	WebDriver driver;
	BeCognizantHome home;
	BeCognizantHolidaySchedules holiday;
	BeCognizantHolidayCalendar holidayCalendar;
	ScreenshotClass ss;
	
	
	//Setting up the WebDriver...
	
	@BeforeClass
	@Parameters({"browser"})
	public void setup(String browser) {
		
		WebDriverSetup driver = new WebDriverSetup();
		
		//Calling WebDriverSetup --> setup()
		driver.setup(browser);
		
		//Calling WebDriverSetup --> getDriver()
		this.driver = driver.getDriver();

		
	}
	
	
	//Closing the driver...
	
	@AfterClass 
	public void close() {
		
		System.out.println("close method called...");
		driver.quit();
		System.out.println("Driver has been closed");
		
	}
	
	
	//Setting up the WebPage...
	
	@Test(priority = 1)
	@Parameters({"url"}) 
	public void setupWebPage(String url) throws Exception {
		
		ss = new ScreenshotClass(driver);
		
		//Initializing the BeCognizantHome driver
		home = new BeCognizantHome(driver);
		
		//Calling BeCognizantHome --> webPageSetup()
		home.webPageSetup(url);
		
		String title = driver.getTitle();
		
		Assert.assertEquals(title,"Be.Cognizant - Home");
	}
	
	
	//Fetching user details...
	
	@Test(priority = 2)
	public void fetchUser() throws Exception {
		
		boolean check = home.captureInfo();
		
		if (check) {
			ss.takeScreenShot("fetchUser");
		}
		
		//Calling BeCognizantHome --> captureInfo
		Assert.assertEquals(check, false);
		
	}
	
	
	//Navigating to HolidaySchedules...
	
	@Test(priority = 3)
	public void navigateToHolidaySchedules() throws Exception {
		
		//Calling BeCognizantHome --> toHolidaySchedules
		home.toHolidaySchedules();
		
		Assert.assertEquals(driver.getTitle(), "Holiday Schedules");
	}
	
	
	//Validating the Holiday Schedules ToolTipText...
	
	@Test(priority = 4) 
	public void validateHolidaySchedules() {
		
		//Initializing the BeCognizantHolidaySchedules driver
		holiday = new BeCognizantHolidaySchedules(driver);
		
		//Holiday Schedules Text...
		String text = holiday.getTextHolidaySchedules();
		
		//Tool Tip Text...
		String toolTipText = holiday.getToolTipHolidaySchedules();
		
		Assert.assertEquals(text, toolTipText);
	}
	
	
	//Printing the Holiday Section's details...
	
	@Test(priority = 5) 
	public void holidaySectionDetails() throws Exception {
		
		boolean check = holiday.sectionDetails();
		
		if (check) ss.takeScreenShot("holidaySectionDetails");
		
		Assert.assertEquals(holiday.sectionDetails(), false);	
		
	}
	
	
	//Validating the Year 2024...
	
	@Test(priority = 6) 
	public void validateHolidayCalendarYear() throws Exception {
		
		String currentYear = "2024";
		String actualYear = holiday.getHolidayCalendarYear().substring(20, 24);
		
		if (!actualYear.equals(currentYear)) ss.takeScreenShot("validateHolidayCalendarYear");
		
		Assert.assertEquals(actualYear, currentYear);
		
	}
	
	
	//Verifying the filter type PDF...
	
	@Test(priority = 7)
	public void verifyTypePDF() throws Exception {
		
		holiday.toIndiaAUKI();
		
		holidayCalendar = new BeCognizantHolidayCalendar(driver);
		
		holidayCalendar.selectPDF();
		
		boolean isTypePDF = holidayCalendar.fetchAllElementType();
		
		System.out.println("Are all the elemnts of PDF Type: " + isTypePDF);
		
		if (!isTypePDF) ss.takeScreenShot("verifyTypePDF");
		Assert.assertEquals(isTypePDF, true);
		
	}
	
	
	//Downloading all files...
	
	@Test(priority = 8) 
	public void downloadAllFiles() throws Exception {
		
		holidayCalendar.downloadAllFiles();
		
	}
	
	
	//Choosing Calendar Based on Location...
	
	@Test(priority = 9) 
	public void chooseCalendar() throws Exception {
		
		//Selecting Calendar based on location
		holidayCalendar.indiaCalendar();
		
		String name = holidayCalendar.calendarName();
		
		if (name.contains("India")) Assert.assertTrue(true);
		else {
			ss.takeScreenShot("chooseCalendar");
			Assert.fail();
		}
		
	}
	

	//Validating the Calendar Name...
	
	@Test(priority = 10)
	public void validateCalendarName() throws Exception {
		
		String name = holidayCalendar.calendarName();
		String toolTipText = holidayCalendar.tooltipText();
		
		if (!name.equals(toolTipText)) {
			ss.takeScreenShot("validateCalendarName");
		}
		
		Assert.assertEquals(name, toolTipText);
		
		
		
	}
	
	
	//Clicking on Version history...
	
	@Test(priority = 11)
	public void versionHistory() throws Exception {
		String vh = holidayCalendar.toVersionHistory();
		
		if (!vh.equals("Version history")) {
			ss.takeScreenShot("validateCalendarName");
		}
		
		//Validating Version History
		Assert.assertEquals(vh, "Version history");
		
	}
	
	
	//Fetching Version history details...
	
	@Test(priority = 12)
	public void versionHistoryDetails() throws Exception {
		
		//Calling verionHistoryDetails
		holidayCalendar.verionHistoryDetails();
			
	}
	
	
}
