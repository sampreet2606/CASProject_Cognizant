package main;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
 
public class ScreenshotClass {
	WebDriver driver;
	
	public ScreenshotClass(WebDriver driver) {
		this.driver = driver;
	}
	
	//Take Screen shot method 
	public void takeScreenShot(String name) throws Exception {
		String timeStamp = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
		TakesScreenshot takesScreenshot = (TakesScreenshot) driver;
		File file = takesScreenshot.getScreenshotAs(OutputType.FILE);
		String path = System.getProperty("user.dir") + "\\screenShots\\" + name + " " + timeStamp + ".png";
		File targetLocation = new File(path);
		FileUtils.copyFile(file, targetLocation);

	}
}